
#include "LinkedList.h"
#include <iostream>

int main(int argc, char** argv) {

//        LinkedList<int> *list = new LinkedList<int>();
//        list->addFirst(64);
//        list->addFirst(32);
//        list->addLast(128);
//        list->addSorted(256);
//        list->addSorted(16);
//        list->addSorted(80);
//        list->print();
//        list->removeFirst();
//        list->print();
//
//        LinkedList<string> *l = new LinkedList<string>();
//        l->addLast("hello");
//        l->addLast("great");
//        l->addLast("world");
//        l->addLast("!");
//        l->print();
//        l->remove(1);
//        l->removeLast();
//        l->print();

        LinkedList<string> *l = new LinkedList<string>();
        l->shell();
        
	system("pause");
        return 0;
}