
#include "LinkedList.h"
#include "SparseMatrix.h"
#include "FastList.h"
#include <iostream>


int compareString(string a, string b) {
    if(a == b) return 0;
    else if (a < b) return -1;
    else return 1;
}

int main(int argc, char** argv) {
//    int N, M;
//    cout << "Digite o tamanho da matrix (NxM): ";
//    fflush(stdin);
//    scanf("%dx%d", &N, &M);
//    if(N < 0 || N > 200) N = 5;
//    if(M < 0 || M > 200) M = 5;
//
//    SparseMatrix<int> matrix(N, M);
//    matrix.shell();

//    matrix.get(0, 0);
//    matrix.set(0, 2, 100);
//    matrix.set(0, 0, 50);
//    matrix.set(0, 1, 1);
//    matrix.set(1, 2, 50);
//    matrix.print();
//
//    matrix.setNull(1, 2);
//    matrix.setNull(0, 6);
//    matrix.setNull(0, 0);
//    matrix.set(0, 2, 400);
//    matrix.set(0, 0, 999);
//    matrix.print();
//
//    matrix.set(0, 0, null);
//    matrix.set(4, 8, 10);
//    matrix.set(4, 4, 20);
//    matrix.set(4, 5, 30);
//    matrix.set(4, 0, 40);
//    matrix.print();
//    matrix.set(4, 5, null);
//    matrix.set(4, 8, null);
//    matrix.print();

    

        //LinkedList<int> *list = new LinkedList<int>();
//        FastList<int> *list = new FastList<int>();
//        list->addFirst(64);
//        list->addFirst(32);
//        list->addLast(128);
//        list->addSorted(256);
//        list->addSorted(16);
//        list->addSorted(80);
//        list->print();
//        list->removeFirst();
//        list->removeLast();
//        list->print();
//
//        FastList<string> *l = new FastList<string>();
//        l->addLast("hello");
//        l->addLast("great");
//        l->addLast("world");
//        l->addLast("!");
//        l->print();
//        l->remove(1);
//        l->removeLast();
//        l->print();

        //LinkedList<string> *l = new LinkedList<string>();
        //l->shell();

        FastList<int> *l = new FastList<int>();
        l->shell();
        
	//system("pause");
        return 0;
}
